# juicenjoy-frontend
This is just a Front_End Online e-commerce website(JuiceNJoy) by using bootstrap framework. This is just for learning purpose and just a bit of fun with html css and javascript.
